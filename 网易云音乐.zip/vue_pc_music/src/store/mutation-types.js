// 设置播放状态
export const SET_PLAYSTATUS = 'SET_PLAYSTATUS'
// 设置播放索引
export const SET_PLAYLIST = 'SET_PLAYLIST'
// 设置播放列表
export const SET_PLAYINDEX = 'SET_PLAYINDEX'
